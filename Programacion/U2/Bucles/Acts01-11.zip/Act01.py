#Crear bucle while que imprima numeros del 1 al 10
i=1
while i<=10:
    print(i)
    i+=1