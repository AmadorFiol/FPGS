#Crear bucle for que muestre todos los numeros pares del 1 al 100

for i in range(1,100):
    if i%2==0:
        print(i)