#Crear bucle while que muestre los numeros primos menores al inidicado por el usuario

num=int(input("Dime un numero: "))
i=1
print("Los numeros primos menores a",num," son:")
while(i<num):
    if 6*i-1>num:
        pass
    elif 6*i+1>num:
        print(6*i-1)
    else:
        print(6*i-1)
        print(6*i+1)
    i+=i