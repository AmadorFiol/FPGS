#Crear un bucle while que muestre todos los nueros pares hasta el 20
i=0
while i!=20:
    if i%2==0:
        print(i)
    i+=1