#Crear script que ìda un nombre y salude si el usuario ha escrito tu nombre
nombre=input("Escribe un nombre: ")
if(nombre=="Amador"):
    print("Hola Amador")