#Crear script que pida un num y la compruebe si esta entre -10 y 10.
#Si esta entre esos valores, enviar mensaje "OK"
num=int(input("Dime un numero (puede ser negativo): "))
if(num>=-10 and num <=10):
    print("OK")