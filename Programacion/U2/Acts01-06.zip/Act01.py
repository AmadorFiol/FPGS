#Crea script en python que pida un num y diga si es > a 10
num=int(input("Dime un num: "))
if(num>10):
    print("El numero es mayor a 10")
else:
    print("El numero es menor a 10")