def ejercicio2(cantidad):
    print("Has pedido ",cantidad," de hamburgesas")
    valor_calculado=cantidad*4.75
    print("El coste de tu pedido es: ",valor_calculado)

cantidad=int(input("Cuantas hamburgesas quieres pedir? "))
ejercicio2(cantidad)