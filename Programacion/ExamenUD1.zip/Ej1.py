'''
Amador Fiol Borel
Examen UD1
10/10/2024
'''
nums=[15,29,34,45,67,88,93]