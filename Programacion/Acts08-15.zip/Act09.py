#Solicitar 2 numeros y realizar la potencia.El primer numero sera la base y el segundo el exponente
base=int(input("Cual sera la base de la potencia? "))
exponente=int(input("Cual sera el exponente de la potencia? "))
res=base**exponente
print("El resultado es: ",res)