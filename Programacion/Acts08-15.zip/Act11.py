#Solicitar un número de días y realizar el cálculo de horas, minutos y segundos
d=int(input("Escribe un numero de dias: "))
h=d*24
m=h*60
s=m*60

print(d," equivale a: ",h," horas o ",m," minutos o ",s," segundos")