#Realizar un conversor de euros a dólares (1€ = 1.07$)
e=float(input("Escribe la cantidad de euros que quieres pasar a dolares: "))
d=e*1.07
print(e,"€ equivale a ",d,"$")