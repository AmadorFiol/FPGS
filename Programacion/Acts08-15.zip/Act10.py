#Solicitar dos numeros y devolver el resto de la division
x=int(input("Escribe un numero: "))
y=int(input("Escribe otro numero: "))
res=x%y