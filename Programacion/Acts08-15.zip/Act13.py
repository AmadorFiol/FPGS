#Define una función que al llamarla te escriba una frase por pantalla.
def WriteFrase():
    print("Esta frase ha sido escrita tras llamar una funcion")

WriteFrase()