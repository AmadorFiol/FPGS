#Define una función que reciba un número por parámetro y devuelva por pantalla su doble
def WriteDoble(num):
    doble=num*2
    print(doble)

num=int(input("Escribe el numero que deseas duplicar: "))
WriteDoble(num)