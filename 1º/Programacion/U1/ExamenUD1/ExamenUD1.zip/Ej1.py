'''
Amador Fiol Borel
Examen UD1
29-10-24
'''
array=[15,29,34,45,67,88,93]