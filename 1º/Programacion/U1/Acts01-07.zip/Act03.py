#Enunciado:Crea la actividad 02 introduciendo dos comentarios. El primero de una sola lines y el segundo de varias
nombre=input("Por favor digame su nombre: ")#Esto es un comentario de una linea
'''
Esto es un comentario de varias lineas.
Increible verdad?
'''
print("Hola",nombre)