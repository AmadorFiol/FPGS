#Enunciado: Escribe un sript de python que envie un mensaje por pantalla que ponga "Hello World"
print("Hello World")