#Enunciado:Pedir nombre de persona por pantalla y guardarlo en una variable despues el programa saludara y despedira a esa persona
nombre=input("Por favor digame su nombre: ")
print("Hola",nombre,"\nAdios",nombre)