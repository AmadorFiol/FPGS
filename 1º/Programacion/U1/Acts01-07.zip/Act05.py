#Declarar una variable, imprimirla cambiarle el valor y volver a imprimirla
num=input("Pon un numero: ")
print("El valor que has escrito a sido",num,", ahora vamos a cambiarlo")
num=input("Escribe otro numero: ")
print("Esta vez has escrito el numero: ",num)
