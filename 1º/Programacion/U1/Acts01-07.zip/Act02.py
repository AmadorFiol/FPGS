#Enunciado: Escribe un script en python que te pregunte un nombre y te salude poniendo "Hola [nombre]" en una linea
nombre=input("Por favor digame su nombre: ")
print("Hola",nombre)
