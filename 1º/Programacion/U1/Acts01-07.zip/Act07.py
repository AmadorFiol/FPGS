#Enunciado: Crea una variable que sea una lista de 5 nombre. Haz un script que vaya saludando a cada una de las personas
nombres=["Juan","Fulanito","Pepe","Maria","Ana"]

for i in nombres:
    print("Hola",i)
