#Crear una lista de las palabras de una frase.
frase="Esta frase sera dividida y almacenada en una lista"
palabras=[palabra for palabra in frase.split()]
print(palabras)