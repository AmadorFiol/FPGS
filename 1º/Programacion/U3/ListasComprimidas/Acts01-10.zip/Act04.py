#Crear una lista comprimida con las letras del alfabeto. Ayúdate del módulo `string`.
import string
array=[char for char in string.ascii_lowercase]
print(array)