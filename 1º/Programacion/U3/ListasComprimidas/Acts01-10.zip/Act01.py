#Crear una lista comprimida con los números del 1 al 10.
array=[num+1 for num in range(0,10)]
print(array)