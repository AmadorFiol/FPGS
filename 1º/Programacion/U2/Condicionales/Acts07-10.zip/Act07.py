#Crear script que pida un num y te diga si es par o impar
num=int(input("Escriba un numero: "))
if (num%2==0):
    print("El numero es par")
else:
    print("El numero es inpar")