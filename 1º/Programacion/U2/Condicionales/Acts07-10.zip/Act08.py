#Crea script que pida dos valores, Si los dos son iguales enviar mensaje "Son identicos" sino enviar "Son diferentes"
msg1=input("Escribe algo: ")
msg2=input("Vuelve a escribir algo: ")
if(msg1==msg2):
    print("Son iguales")
else:
    print("Son diferentes")